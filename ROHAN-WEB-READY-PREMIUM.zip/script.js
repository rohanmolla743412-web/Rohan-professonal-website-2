const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const phrases=['Web Developer','Creative Builder','Problem Solver','Future Engineer'];
let pi=0,ci=0,del=false;
function type(){const el=$('#typing');if(!el)return;const word=phrases[pi];el.textContent=word.slice(0,ci);if(!del){ci++;if(ci>word.length){del=true;setTimeout(type,1000);return}}else{ci--;if(ci<0){ci=0;del=false;pi=(pi+1)%phrases.length}}setTimeout(type,del?45:75)}
// subtle typing element inserted into hero title metadata
const lead=document.querySelector('.lead'); if(lead){const line=document.createElement('div');line.className='typing-line';line.innerHTML='Currently exploring <span id="typing"></span><i>|</i>';lead.after(line)} type();
const saved=localStorage.getItem('rohan-theme')||'dark';document.documentElement.dataset.theme=saved;const theme=$('#theme');if(theme)theme.textContent=saved==='dark'?'☼':'☾';theme?.addEventListener('click',()=>{const t=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=t;localStorage.setItem('rohan-theme',t);theme.textContent=t==='dark'?'☼':'☾'});
$('#menu')?.addEventListener('click',()=>$('#links')?.classList.toggle('open'));$$('.links a').forEach(a=>a.addEventListener('click',()=>$('#links')?.classList.remove('open')));
const progress=$('#progress'),top=$('#top'),sections=[...$$('section[id]')],nav=[...$$('.links a')];window.addEventListener('scroll',()=>{const h=document.documentElement.scrollHeight-innerHeight;progress.style.width=(scrollY/Math.max(h,1)*100)+'%';top.classList.toggle('show',scrollY>500);let cur='home';sections.forEach(s=>{if(scrollY>=s.offsetTop-230)cur=s.id});nav.forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+cur))});
top?.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));
$('#contactForm')?.addEventListener('submit',e=>{e.preventDefault();const n=$('#name').value.trim(),m=$('#message').value.trim();if(!n||!m)return;alert('Thanks, '+n+'! Your message is ready.');e.target.reset()});

// Final visual polish: gentle reveal + smarter glass navbar
const revealItems=document.querySelectorAll('.section-title,.about-grid,.skill-grid,.project-grid,.contact-box');
revealItems.forEach(el=>el.classList.add('reveal'));
const revealObserver=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');revealObserver.unobserve(entry.target)}})},{threshold:.12});
revealItems.forEach(el=>revealObserver.observe(el));
const mainNav=document.querySelector('.nav');
window.addEventListener('scroll',()=>mainNav?.classList.toggle('scrolled',window.scrollY>30),{passive:true});

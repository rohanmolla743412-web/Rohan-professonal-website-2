const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const saved=localStorage.getItem('rohan-theme')||'dark';document.documentElement.dataset.theme=saved;
const theme=$('#theme');if(theme)theme.textContent=saved==='dark'?'☼':'☾';
theme?.addEventListener('click',()=>{const t=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=t;localStorage.setItem('rohan-theme',t);theme.textContent=t==='dark'?'☼':'☾'});
$('#menu')?.addEventListener('click',()=>$('#links')?.classList.toggle('open'));
$$('.links a').forEach(a=>a.addEventListener('click',()=>$('#links')?.classList.remove('open')));
const top=$('#top');top?.addEventListener('click',()=>window.scrollTo({top:0,behavior:'auto'}));
$('#contactForm')?.addEventListener('submit',e=>{e.preventDefault();const n=$('#name').value.trim(),m=$('#message').value.trim();if(!n||!m)return;alert('Thanks, '+n+'! Your message is ready.');e.target.reset()});

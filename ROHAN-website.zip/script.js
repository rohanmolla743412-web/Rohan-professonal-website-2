document.querySelectorAll('.links a').forEach(link=>{
  link.addEventListener('click',()=>window.scrollTo({top:document.querySelector(link.getAttribute('href')).offsetTop-50,behavior:'smooth'}));
});

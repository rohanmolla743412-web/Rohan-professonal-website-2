const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const phrases=['Web Developer','Creative Builder','Problem Solver','Future Engineer'];
let pi=0,ci=0,del=false;
const reduceMotion=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function type(){const el=$('#typing');if(!el||reduceMotion)return;const word=phrases[pi];el.textContent=word.slice(0,ci);if(!del){ci++;if(ci>word.length){del=true;setTimeout(type,1000);return}}else{ci--;if(ci<0){ci=0;del=false;pi=(pi+1)%phrases.length}}setTimeout(type,del?45:75)}
const lead=document.querySelector('.lead');if(lead){const line=document.createElement('div');line.className='typing-line';line.innerHTML='Currently exploring <span id="typing"></span><i>|</i>';lead.after(line)}type();
const saved=localStorage.getItem('rohan-theme')||'dark';document.documentElement.dataset.theme=saved;const theme=$('#theme');if(theme)theme.textContent=saved==='dark'?'☼':'☾';theme?.addEventListener('click',()=>{const t=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=t;localStorage.setItem('rohan-theme',t);theme.textContent=t==='dark'?'☼':'☾'});
$('#menu')?.addEventListener('click',()=>$('#links')?.classList.toggle('open'));$$('.links a').forEach(a=>a.addEventListener('click',()=>$('#links')?.classList.remove('open')));
const progress=$('#progress'),top=$('#top'),sections=[...$$('section[id]')],nav=[...$$('.links a')];
let ticking=false;function updateScroll(){const y=window.scrollY;const h=document.documentElement.scrollHeight-window.innerHeight;if(progress)progress.style.width=(y/Math.max(h,1)*100)+'%';top?.classList.toggle('show',y>500);let cur='home';for(const s of sections){if(y>=s.offsetTop-230)cur=s.id}nav.forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+cur));document.querySelector('.nav')?.classList.toggle('scrolled',y>30);ticking=false}
window.addEventListener('scroll',()=>{if(!ticking){requestAnimationFrame(updateScroll);ticking=true}},{passive:true});updateScroll();
top?.addEventListener('click',()=>scrollTo({top:0,behavior:reduceMotion?'auto':'smooth'}));
$('#contactForm')?.addEventListener('submit',e=>{e.preventDefault();const n=$('#name').value.trim(),m=$('#message').value.trim();if(!n||!m)return;alert('Thanks, '+n+'! Your message is ready.');e.target.reset()});
const revealItems=document.querySelectorAll('.section-title,.about-grid,.skill-grid,.project-grid,.project-feature,.contact-box');revealItems.forEach(el=>el.classList.add('reveal'));
if('IntersectionObserver'in window&&!reduceMotion){const revealObserver=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');revealObserver.unobserve(entry.target)}})},{threshold:.08});revealItems.forEach(el=>revealObserver.observe(el))}else revealItems.forEach(el=>el.classList.add('visible'));

const $=s=>document.querySelector(s);const progress=$('#progress'),menu=$('#menu'),links=$('#links'),theme=$('#theme'),topBtn=$('#top');
menu?.addEventListener('click',()=>links.classList.toggle('open'));
links?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>links.classList.remove('open')));
function update(){const h=document.documentElement.scrollHeight-innerHeight;progress.style.width=(h>0?(scrollY/h)*100:0)+'%';topBtn.style.opacity=scrollY>500?'1':'0'}
let ticking=false;addEventListener('scroll',()=>{if(!ticking){requestAnimationFrame(()=>{update();ticking=false});ticking=true}},{passive:true});update();
topBtn?.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));
theme?.addEventListener('click',()=>{document.body.classList.toggle('light');theme.textContent=document.body.classList.contains('light')?'☾':'☼'});
$('#contactForm')?.addEventListener('submit',e=>{e.preventDefault();alert('Thanks! Your message is ready to send.');e.target.reset()});
